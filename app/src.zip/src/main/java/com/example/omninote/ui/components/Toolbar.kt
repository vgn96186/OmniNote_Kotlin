package com.example.omninote.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.omninote.data.ToolType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CanvasToolbar(
    currentTool: ToolType,
    color: Color,
    width: Float,
    opacity: Float,
    grid: Boolean,
    dots: Boolean,
    stylusOnly: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onToolChange: (ToolType) -> Unit,
    onColorChange: (Color) -> Unit,
    onWidthChange: (Float) -> Unit,
    onOpacityChange: (Float) -> Unit,
    onGridToggle: (Boolean) -> Unit,
    onDotsToggle: (Boolean) -> Unit,
    onStylusOnlyToggle: (Boolean) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onClear: () -> Unit,
    onExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    var colorMenuOpen by remember { mutableStateOf(false) }
    var widthMenuOpen by remember { mutableStateOf(false) }
    var overflowOpen by remember { mutableStateOf(false) }

    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val tools = listOf(
                ToolType.PEN to Pair(Icons.Filled.Edit, "Pen"),
                ToolType.HIGHLIGHTER to Pair(Icons.Filled.Brush, "Highlighter"),
                ToolType.ERASER to Pair(Icons.Filled.Clear, "Eraser"),
                ToolType.SHAPE_DRAWER to Pair(Icons.Filled.Category, "Shape")
            )
            val selectedIndex =
                tools.indexOfFirst { it.first == currentTool }.let { if (it == -1) 0 else it }

            SingleChoiceSegmentedButtonRow {
                tools.forEachIndexed { index, (tool, meta) ->
                    SegmentedButton(
                        selected = index == selectedIndex,
                        onClick = { onToolChange(tool) },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = tools.size)
                    ) {
                        Icon(
                            imageVector = meta.first,
                            contentDescription = meta.second,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            VerticalDivider(
                modifier = Modifier
                    .height(28.dp),
                color = MaterialTheme.colorScheme.outline
            )

            Box {
                AssistChip(
                    onClick = { colorMenuOpen = true },
                    label = { Text("Color") },
                    leadingIcon = {
                        Box(
                            Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(color)
                        )
                    }
                )
                DropdownMenu(
                    expanded = colorMenuOpen,
                    onDismissRequest = { colorMenuOpen = false }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        ColorPalette(currentColor = color, onColorSelected = {
                            onColorChange(it.copy(alpha = opacity))
                            colorMenuOpen = false
                        })
                        Spacer(Modifier.height(8.dp))
                        Text("Opacity", style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = opacity,
                            onValueChange = {
                                onOpacityChange(it)
                                onColorChange(color.copy(alpha = it))
                            },
                            valueRange = 0.1f..1f
                        )
                    }
                }
            }

            Box {
                AssistChip(
                    onClick = { widthMenuOpen = true },
                    label = { Text("Width: ${width.toInt()}") }
                )
                DropdownMenu(
                    expanded = widthMenuOpen,
                    onDismissRequest = { widthMenuOpen = false }
                ) {
                    Column(Modifier.padding(horizontal = 12.dp)) {
                        Text("Stroke width", style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = width,
                            onValueChange = onWidthChange,
                            valueRange = 1f..20f
                        )
                    }
                }
            }

            VerticalDivider(
                modifier = Modifier
                    .height(28.dp),
                color = MaterialTheme.colorScheme.outline
            )

            FilterChip(
                selected = grid,
                onClick = { onGridToggle(!grid) },
                label = { Text("Grid") }
            )
            FilterChip(
                selected = dots,
                onClick = { onDotsToggle(!dots) },
                label = { Text("Dots") }
            )
            FilterChip(
                selected = stylusOnly,
                onClick = { onStylusOnlyToggle(!stylusOnly) },
                label = { Text("Stylus") }
            )

            Spacer(Modifier.weight(1f))

            IconButton(onClick = onUndo, enabled = canUndo) {
                Icon(
                    Icons.Filled.Undo,
                    contentDescription = "Undo"
                )
            }
            IconButton(onClick = onRedo, enabled = canRedo) {
                Icon(
                    Icons.Filled.Redo,
                    contentDescription = "Redo"
                )
            }

            Box {
                IconButton(onClick = { overflowOpen = true }) {
                    Icon(
                        Icons.Filled.MoreVert,
                        contentDescription = "More"
                    )
                }
                DropdownMenu(
                    expanded = overflowOpen,
                    onDismissRequest = { overflowOpen = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Clear canvas") },
                        onClick = {
                            overflowOpen = false
                            onClear()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Export...") },
                        onClick = {
                            overflowOpen = false
                            onExport()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ColorPalette(
    currentColor: Color,
    onColorSelected: (Color) -> Unit
) {
    val colors = listOf(
        Color.Black,
        Color.Red,
        Color.Green,
        Color.Blue,
        Color.Yellow,
        Color.Magenta,
        Color.Cyan,
        Color.Gray
    )

    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        colors.forEach { color ->
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(color)
                    .border(
                        width = if (currentColor.copy(alpha = 1f) == color) 3.dp else 1.dp,
                        color = if (currentColor.copy(alpha = 1f) == color) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            Color.Gray
                        },
                        shape = CircleShape
                    )
                    .clickable { onColorSelected(color) }
            )
        }
    }
}

@Composable
fun NoteToolbar(
    onNewNote: () -> Unit,
    onSearch: () -> Unit,
    onShowGraph: () -> Unit,
    onExport: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ActionButton(
                icon = Icons.Filled.Add,
                onClick = onNewNote,
                contentDescription = "New Note"
            )
            ActionButton(
                icon = Icons.Filled.Search,
                onClick = onSearch,
                contentDescription = "Search"
            )
            ActionButton(
                icon = Icons.Filled.AccountTree,
                onClick = onShowGraph,
                contentDescription = "Knowledge Graph"
            )
            ActionButton(
                icon = Icons.Filled.Download,
                onClick = onExport,
                contentDescription = "Export"
            )
            ActionButton(
                icon = Icons.Filled.Settings,
                onClick = onSettings,
                contentDescription = "Settings"
            )
        }
    }
}

@Composable
private fun ActionButton(
    icon: ImageVector,
    onClick: () -> Unit,
    contentDescription: String
) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun DrawingToolbar(
    currentTool: ToolType,
    currentColor: Color,
    strokeWidth: Float,
    onToolChanged: (ToolType) -> Unit,
    onColorChanged: (Color) -> Unit,
    onStrokeWidthChanged: (Float) -> Unit,
    onClearCanvas: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolButton(
                tool = ToolType.PEN,
                icon = Icons.Filled.Edit,
                isSelected = currentTool == ToolType.PEN
            ) { onToolChanged(ToolType.PEN) }

            ToolButton(
                tool = ToolType.HIGHLIGHTER,
                icon = Icons.Filled.Brush,
                isSelected = currentTool == ToolType.HIGHLIGHTER
            ) { onToolChanged(ToolType.HIGHLIGHTER) }

            ToolButton(
                tool = ToolType.ERASER,
                icon = Icons.Filled.Clear,
                isSelected = currentTool == ToolType.ERASER
            ) { onToolChanged(ToolType.ERASER) }

            ToolButton(
                tool = ToolType.SHAPE_DRAWER,
                icon = Icons.Filled.Category,
                isSelected = currentTool == ToolType.SHAPE_DRAWER
            ) { onToolChanged(ToolType.SHAPE_DRAWER) }

            VerticalDivider(
                modifier = Modifier
                    .height(40.dp),
                color = MaterialTheme.colorScheme.outline
            )

            ColorPalette(currentColor = currentColor, onColorSelected = onColorChanged)

            VerticalDivider(
                modifier = Modifier
                    .height(40.dp),
                color = MaterialTheme.colorScheme.outline
            )

            StrokeWidthSelector(
                currentWidth = strokeWidth,
                onWidthChanged = onStrokeWidthChanged
            )

            VerticalDivider(
                modifier = Modifier
                    .height(40.dp),
                color = MaterialTheme.colorScheme.outline
            )

            ActionButton(
                icon = Icons.Filled.Undo,
                onClick = onUndo,
                contentDescription = "Undo"
            )
            ActionButton(
                icon = Icons.Filled.Redo,
                onClick = onRedo,
                contentDescription = "Redo"
            )
            ActionButton(
                icon = Icons.Filled.Clear,
                onClick = onClearCanvas,
                contentDescription = "Clear Canvas"
            )
        }
    }
}

@Composable
private fun ToolButton(
    tool: ToolType,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val backgroundColor = if (isSelected) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surface
    }
    val iconTint = if (isSelected) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(backgroundColor)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.outline
                },
                shape = CircleShape
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            contentDescription = tool.name,
            tint = iconTint,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
private fun StrokeWidthSelector(
    currentWidth: Float,
    onWidthChanged: (Float) -> Unit
) {
    val widths = listOf(2f, 4f, 6f, 8f, 12f)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "Width",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            widths.forEach { w ->
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(
                            if (currentWidth == w) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.surface
                            }
                        )
                        .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable { onWidthChanged(w) },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(w.dp)
                            .clip(CircleShape)
                            .background(
                                if (currentWidth == w) Color.White else Color.Black
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun VerticalDivider(modifier: Modifier = Modifier, color: Color = Color.LightGray) {
    Box(
        modifier = modifier
            .width(1.dp)
            .fillMaxHeight()
            .background(color)
    )
}
@Preview(showBackground = true)
@Composable
private fun PreviewDrawingToolbar() {
    DrawingToolbar(
        currentTool = ToolType.PEN,
        currentColor = Color.Black,
        strokeWidth = 4f,
        onToolChanged = {},
        onColorChanged = {},
        onStrokeWidthChanged = {},
        onClearCanvas = {},
        onUndo = {},
        onRedo = {}
    )
}