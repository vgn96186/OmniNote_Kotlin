package com.example.omninote.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.omninote.data.Stroke
import com.example.omninote.data.ToolType
import com.example.omninote.ui.components.DrawingCanvas
import com.example.omninote.ui.components.DrawingToolbar

@Composable
fun InfiniteCanvasWithTools() {
    var strokes by remember { mutableStateOf(emptyList<Stroke>()) }
    var currentStroke by remember { mutableStateOf<Stroke?>(null) }
    var currentTool by remember { mutableStateOf(ToolType.PEN) }
    var currentColor by remember { mutableStateOf(Color.Black) }
    var strokeWidth by remember { mutableStateOf(6f) }

    Column(modifier = Modifier.fillMaxSize()) {
        DrawingToolbar(
            currentTool = currentTool,
            currentColor = currentColor,
            strokeWidth = strokeWidth,
            onToolChanged = { currentTool = it },
            onColorChanged = { currentColor = it },
            onStrokeWidthChanged = { strokeWidth = it },
            onClearCanvas = { strokes = emptyList() },
            onUndo = { /* TODO */ },
            onRedo = { /* TODO */ }
        )
        DrawingCanvas(
            strokes = strokes,
            currentStroke = currentStroke,
            onStrokeStart = { currentStroke = it },
            onStrokeUpdate = { currentStroke = it },
            onStrokeEnd = { 
                strokes = strokes + it
                currentStroke = null
            },
            toolType = currentTool,
            strokeColor = currentColor,
            strokeWidth = strokeWidth,
            modifier = Modifier.fillMaxSize()
        )
    }
}