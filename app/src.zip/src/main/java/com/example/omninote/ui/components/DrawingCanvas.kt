package com.example.omninote.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.unit.dp
import com.example.omninote.data.Point
import com.example.omninote.data.Stroke as DataStroke
import com.example.omninote.data.ToolType
import kotlin.collections.isNotEmpty
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

@Composable
fun DrawingCanvas(
    strokes: List<DataStroke>,
    currentStroke: DataStroke?,
    onStrokeStart: (DataStroke) -> Unit,
    onStrokeUpdate: (DataStroke) -> Unit,
    onStrokeEnd: (DataStroke) -> Unit,
    toolType: ToolType = ToolType.PEN,
    strokeColor: Color = Color.Black,
    strokeWidth: Float = 6f,
    showGrid: Boolean = false,
    showDots: Boolean = false,
    stylusOnly: Boolean = false,
    onEraseStrokes: (List<DataStroke>) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var currentPoints by remember { mutableStateOf(listOf<Point>()) }
    var velocityTracker by remember { mutableStateOf<VelocityTracker?>(null) }
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.3f, 4f)
                    offset += pan
                }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { touchOffset ->
                        velocityTracker = VelocityTracker()
                        currentPoints = listOf(
                            Point(
                                x = (touchOffset.x - offset.x) / scale,
                                y = (touchOffset.y - offset.y) / scale,
                                pressure = 1.0f,
                                timestamp = System.currentTimeMillis()
                            )
                        )

                        val stroke = DataStroke(
                            noteId = 0,
                            points = currentPoints,
                            color = when (toolType) {
                                ToolType.HIGHLIGHTER -> strokeColor.copy(alpha = 0.3f).toArgb()
                                else -> strokeColor.toArgb()
                            },
                            strokeWidth = strokeWidth,
                            toolType = toolType
                        )
                        onStrokeStart(stroke)
                    },
                    onDrag = { change, _ ->
                        if (stylusOnly && change.type != PointerType.Stylus) return@detectDragGestures
                        velocityTracker?.addPosition(
                            change.uptimeMillis,
                            change.position
                        )

                        val pressure = when (toolType) {
                            ToolType.PEN -> 1.0f
                            ToolType.HIGHLIGHTER -> 0.6f
                            ToolType.ERASER -> 1.0f
                            ToolType.SHAPE_DRAWER -> 1.0f
                        }

                        val worldX = (change.position.x - offset.x) / scale
                        val worldY = (change.position.y - offset.y) / scale
                        val newPoint = Point(
                            x = worldX,
                            y = worldY,
                            pressure = pressure,
                            timestamp = System.currentTimeMillis()
                        )

                        currentPoints = currentPoints + newPoint

                        val stroke = DataStroke(
                            noteId = 0,
                            points = currentPoints,
                            color = when (toolType) {
                                ToolType.HIGHLIGHTER -> strokeColor.copy(alpha = 0.3f).toArgb()
                                else -> strokeColor.toArgb()
                            },
                            strokeWidth = strokeWidth,
                            pressure = pressure,
                            toolType = toolType
                        )
                        onStrokeUpdate(stroke)
                    },
                    onDragEnd = {
                        velocityTracker?.let { tracker ->
                            val velocity = tracker.calculateVelocity()
                            val speed = sqrt(velocity.x * velocity.x + velocity.y * velocity.y)

                            val smoothedPoints = if (speed > 1000f) {
                                smoothPoints(currentPoints)
                            } else {
                                currentPoints
                            }

                            if (toolType == ToolType.ERASER) {
                                val toDelete =
                                    findStrokesNearPath(strokes, smoothedPoints, threshold = 20f)
                                if (toDelete.isNotEmpty()) onEraseStrokes(toDelete)
                            } else {
                                val finalStroke = DataStroke(
                                    noteId = 0,
                                    points = smoothedPoints,
                                    color = when (toolType) {
                                        ToolType.HIGHLIGHTER -> strokeColor.copy(alpha = 0.3f)
                                            .toArgb()

                                        else -> strokeColor.toArgb()
                                    },
                                    strokeWidth = strokeWidth,
                                    toolType = toolType
                                )
                                onStrokeEnd(finalStroke)
                            }
                        }

                        currentPoints = emptyList()
                        velocityTracker = null
                    }
                )
            }
    ) {
        withTransform({
            translate(offset.x, offset.y)
            scale(scale, scale)
        }) {
            if (showGrid) drawGrid(step = 32f, color = Color(0xFFE0E0E0))
            if (showDots) drawDots(step = 32f, radius = 1.5f, color = Color(0xFFBDBDBD))
        }

        withTransform({
            translate(offset.x, offset.y)
            scale(scale, scale)
        }) {
            strokes.forEach { stroke ->
                drawStroke(stroke)
            }
            currentStroke?.let { stroke ->
                drawStroke(stroke)
            }
        }
    }
}

private fun DrawScope.drawStroke(stroke: DataStroke) {
    if (stroke.points.isEmpty()) return

    val path = Path().apply {
        val firstPoint = stroke.points.first()
        moveTo(firstPoint.x, firstPoint.y)

        stroke.points.drop(1).forEach { point ->
            lineTo(point.x, point.y)
        }
    }

    val color = Color(stroke.color)
    val width = stroke.strokeWidth * stroke.pressure

    when (stroke.toolType) {
        ToolType.PEN -> {
            drawPath(
                path = path,
                color = color,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = width,
                    cap = StrokeCap.Round
                )
            )
        }
        ToolType.HIGHLIGHTER -> {
            drawPath(
                path = path,
                color = color.copy(alpha = 0.3f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = width * 2,
                    cap = StrokeCap.Round
                )
            )
        }
        ToolType.ERASER -> {
            drawPath(
                path = path,
                color = Color.White,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = width * 2,
                    cap = StrokeCap.Round
                )
            )
        }
        ToolType.SHAPE_DRAWER -> {
            drawPath(
                path = path,
                color = color,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = width,
                    cap = StrokeCap.Round
                )
            )
        }
        else -> {}
    }
}

private fun smoothPoints(points: List<Point>): List<Point> {
    if (points.size < 3) return points

    val smoothed = mutableListOf<Point>()
    smoothed.add(points.first())

    for (i in 1 until points.size - 1) {
        val prev = points[i - 1]
        val current = points[i]
        val next = points[i + 1]

        val smoothedX = (prev.x + current.x + next.x) / 3f
        val smoothedY = (prev.y + current.y + next.y) / 3f

        smoothed.add(
            Point(
                x = smoothedX,
                y = smoothedY,
                pressure = current.pressure,
                timestamp = current.timestamp
            )
        )
    }

    smoothed.add(points.last())
    return smoothed
}

private fun DrawScope.drawGrid(step: Float, color: Color) {
    val cols = (size.width / step).toInt() + 1
    val rows = (size.height / step).toInt() + 1
    val stroke = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f)
    for (c in 0..cols) {
        val x = c * step
        drawLine(
            color,
            start = Offset(x, 0f),
            end = Offset(x, size.height),
            strokeWidth = stroke.width
        )
    }
    for (r in 0..rows) {
        val y = r * step
        drawLine(
            color,
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = stroke.width
        )
    }
}

private fun DrawScope.drawDots(step: Float, radius: Float, color: Color) {
    val cols = (size.width / step).toInt() + 1
    val rows = (size.height / step).toInt() + 1
    for (c in 0..cols) {
        for (r in 0..rows) {
            drawCircle(color = color, radius = radius, center = Offset(c * step, r * step))
        }
    }
}

private fun findStrokesNearPath(
    strokes: List<DataStroke>,
    path: List<Point>,
    threshold: Float
): List<DataStroke> {
    fun pointSegmentDistance(
        px: Float,
        py: Float,
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float
    ): Float {
        val dx = bx - ax
        val dy = by - ay
        if (dx == 0f && dy == 0f) return hypot(px - ax, py - ay)
        val t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)
        val clamped = t.coerceIn(0f, 1f)
        val nx = ax + clamped * dx
        val ny = ay + clamped * dy
        return hypot(px - nx, py - ny)
    }

    val result = mutableListOf<DataStroke>()
    for (stroke in strokes) {
        var hit = false
        val pts = stroke.points
        if (pts.size < 2) continue
        outer@ for (i in 0 until pts.size - 1) {
            val a = pts[i]
            val b = pts[i + 1]
            for (p in path) {
                val d = pointSegmentDistance(p.x, p.y, a.x, a.y, b.x, b.y)
                if (d <= threshold) {
                    hit = true; break@outer
                }
            }
        }
        if (hit) result.add(stroke)
    }
    return result
}
