package com.example.omninote.ui.screens

import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding

@Composable
fun FolderExplorer(
    onCreateCanvas: () -> Unit,
    onCreateFolder: () -> Unit,
    onCreateTextNote: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Folder Explorer", style = MaterialTheme.typography.headlineMedium)

        Button(onClick = onCreateCanvas) {
            Text("Create Infinite Canvas")
        }

        Button(onClick = onCreateFolder) {
            Text("Create New Folder")
        }

        Button(onClick = onCreateTextNote) {
            Text("Create Text Note")
        }
    }
}
