package com.example.omninote.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.omninote.data.Note
import com.example.omninote.data.NoteType
import com.example.omninote.ui.screens.InfiniteCanvasWithTools

import com.example.omninote.viewmodel.NoteViewModel

@Composable
fun NoteDetail(
    note: Note,
    viewModel: NoteViewModel // Added viewModel to allow back navigation
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        IconButton(onClick = { viewModel.selectNote(null) }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Folders")
        }
        Text(
            text = note.title,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )
        when (note.type) {
            NoteType.TEXT -> {
                Text(
                    text = note.content,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            NoteType.CANVAS -> {
                InfiniteCanvasWithTools()
            }
            NoteType.KNOWLEDGE_GRAPH -> {
                Text(
                    text = "Knowledge Graph View",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            NoteType.FOLDER -> {
                Text(
                    text = "Folder",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
