package com.example.omninote.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.omninote.data.Note
import com.example.omninote.data.NoteType
import com.example.omninote.data.Stroke
import com.example.omninote.data.ToolbarPosition
import com.example.omninote.repository.NoteRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDateTime

class NoteViewModel(private val repository: NoteRepository) : ViewModel() {
    
    private val _notes = MutableStateFlow<List<Note>>(emptyList())
    val notes: StateFlow<List<Note>> = _notes.asStateFlow()
    
    private val _topLevelNotes = MutableStateFlow<List<Note>>(emptyList())
    val topLevelNotes: StateFlow<List<Note>> = _topLevelNotes.asStateFlow()
    
    private val _currentNote = MutableStateFlow<Note?>(null)
    val currentNote: StateFlow<Note?> = _currentNote.asStateFlow()
    
    private val _strokes = MutableStateFlow<List<Stroke>>(emptyList())
    val strokes: StateFlow<List<Stroke>> = _strokes.asStateFlow()
    
    private val _searchResults = MutableStateFlow<List<Note>>(emptyList())
    val searchResults: StateFlow<List<Note>> = _searchResults.asStateFlow()
    
    private val _knowledgeGraph = MutableStateFlow<Map<Long, List<Long>>>(emptyMap())
    val knowledgeGraph: StateFlow<Map<Long, List<Long>>> = _knowledgeGraph.asStateFlow()

    private val _toolbarPosition = MutableStateFlow(ToolbarPosition.TOP)
    val toolbarPosition: StateFlow<ToolbarPosition> = _toolbarPosition.asStateFlow()

    private val _canvasGridEnabled = MutableStateFlow(false)
    val canvasGridEnabled: StateFlow<Boolean> = _canvasGridEnabled.asStateFlow()

    private val _canvasDotsEnabled = MutableStateFlow(false)
    val canvasDotsEnabled: StateFlow<Boolean> = _canvasDotsEnabled.asStateFlow()

    private val _stylusOnly = MutableStateFlow(false)
    val stylusOnly: StateFlow<Boolean> = _stylusOnly.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureSampleDataLoaded()
        }
        loadNotes()
        loadTopLevelNotes()
        loadKnowledgeGraph()
    }
    
    private fun loadNotes() {
        viewModelScope.launch {
            repository.getAllNotes().collect { notesList ->
                _notes.value = notesList
            }
        }
    }
    
    private fun loadTopLevelNotes() {
        viewModelScope.launch {
            repository.getTopLevelNotes().collect { topNotes ->
                _topLevelNotes.value = topNotes
            }
        }
    }
    
    fun getChildNotes(parentId: Long): Flow<List<Note>> {
        return repository.getChildNotes(parentId)
    }
    
    private fun loadKnowledgeGraph() {
        viewModelScope.launch {
            _knowledgeGraph.value = repository.getKnowledgeGraph()
        }
    }

    fun createNote(
        title: String,
        type: NoteType = NoteType.TEXT,
        content: String = "",
        parentNoteId: Long? = null
    ) {
        viewModelScope.launch {
            val note = Note(
                title = title,
                content = content,
                type = type,
                parentNoteId = parentNoteId,
                createdAt = LocalDateTime.now(),
                updatedAt = LocalDateTime.now()
            )
            val noteId = repository.insertNote(note)
            loadNotes()
            // Only select non-folder notes
            if (type != NoteType.FOLDER) {
                _currentNote.value = note.copy(id = noteId)
                loadStrokesForNote(noteId)
            }
        }
    }
    
    fun selectNote(note: Note?) {
        // Don't select folders as current note
        if (note?.type == NoteType.FOLDER) return
        
        _currentNote.value = note
        if (note != null) {
            loadStrokesForNote(note.id)
        } else {
            _strokes.value = emptyList() 
        }
    }
    
    fun updateNote(note: Note) {
        viewModelScope.launch {
            val updatedNote = note.copy(updatedAt = LocalDateTime.now())
            repository.updateNote(updatedNote)
            if (_currentNote.value?.id == note.id) {
                _currentNote.value = updatedNote
            }
        }
    }
    
    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.deleteNote(note)
            if (_currentNote.value?.id == note.id) {
                _currentNote.value = null
                _strokes.value = emptyList()
            }
        }
    }
    
    fun searchNotes(query: String) {
        viewModelScope.launch {
            if (query.isBlank()) {
                _searchResults.value = emptyList()
            } else {
                _searchResults.value = repository.searchNotes(query)
            }
        }
    }
    
    fun addStroke(stroke: Stroke) {
        viewModelScope.launch {
            repository.insertStroke(stroke)
        }
    }
    
    fun addStrokes(strokes: List<Stroke>) {
        viewModelScope.launch {
            repository.insertStrokes(strokes)
        }
    }

    fun deleteStroke(stroke: Stroke) {
        viewModelScope.launch {
            repository.deleteStroke(stroke)
        }
    }

    private fun loadStrokesForNote(noteId: Long) {
        viewModelScope.launch {
            repository.getStrokesForNote(noteId).collect { strokesList ->
                _strokes.value = strokesList
            }
        }
    }

    fun strokesForNote(noteId: Long): Flow<List<Stroke>> = repository.getStrokesForNote(noteId)

    fun clearStrokes() {
        viewModelScope.launch {
            _currentNote.value?.let { note ->
                repository.deleteStrokesForNote(note.id)
            }
        }
    }
    
    fun getRelatedNotes(noteId: Long) {
        viewModelScope.launch {
            val related = repository.getRelatedNotes(noteId)
            // You could add a separate state flow for related notes if needed
        }
    }
    
    fun createLink(sourceId: Long, targetId: Long) {
        viewModelScope.launch {
            repository.createLink(sourceId, targetId)
            loadKnowledgeGraph()
        }
    }
    
    fun deleteLink(sourceId: Long, targetId: Long) {
        viewModelScope.launch {
            repository.deleteLink(sourceId, targetId)
            loadKnowledgeGraph()
        }
    }

    fun selectNoteById(noteId: Long) {
        viewModelScope.launch {
            val note = repository.getNoteById(noteId)
            selectNote(note)
        }
    }

    fun setToolbarPosition(position: ToolbarPosition) {
        _toolbarPosition.value = position
    }

    fun setCanvasGridEnabled(enabled: Boolean) {
        _canvasGridEnabled.value = enabled
    }

    fun setCanvasDotsEnabled(enabled: Boolean) {
        _canvasDotsEnabled.value = enabled
    }

    fun setStylusOnly(enabled: Boolean) {
        _stylusOnly.value = enabled
    }
}
