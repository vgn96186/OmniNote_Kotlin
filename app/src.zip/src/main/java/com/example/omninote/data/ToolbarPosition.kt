package com.example.omninote.data

enum class ToolbarPosition {
    TOP,
    BOTTOM
}
