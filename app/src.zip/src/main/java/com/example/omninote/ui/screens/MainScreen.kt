package com.example.omninote.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.omninote.data.Note
import com.example.omninote.data.NoteType
import com.example.omninote.data.Stroke
import com.example.omninote.data.ToolType
import com.example.omninote.data.ToolbarPosition
import com.example.omninote.ui.components.*
import com.example.omninote.ui.theme.OmniNoteTheme
import com.example.omninote.viewmodel.NoteViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    modifier: Modifier = Modifier, // Added modifier to Scaffold
    viewModel: NoteViewModel
) {
    var selectedFolderId by remember { mutableStateOf<Long?>(null) }
    val currentNote by viewModel.currentNote.collectAsState()
    var screenMode by remember { mutableStateOf(ScreenMode.Home) }

    OmniNoteTheme {
        Scaffold(
            modifier = modifier, // Used modifier here
            topBar = {
                TopAppBar(
                    title = {
                        val title = when {
                            currentNote != null -> currentNote!!.title
                            screenMode == ScreenMode.Search -> "Search"
                            screenMode == ScreenMode.Settings -> "Settings"
                            screenMode == ScreenMode.Graph -> "Knowledge Graph"
                            else -> "OmniNote"
                        }
                        Text(title)
                    },
                    navigationIcon = {
                        if (currentNote != null) {
                            IconButton(onClick = { viewModel.selectNote(null) }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back"
                                )
                            }
                        } else if (screenMode != ScreenMode.Home) {
                            IconButton(onClick = { screenMode = ScreenMode.Home }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back"
                                )
                            }
                        }
                    },
                    actions = {
                        if (currentNote == null) {
                            IconButton(onClick = { screenMode = ScreenMode.Search }) {
                                Icon(imageVector = Icons.Filled.Search, contentDescription = "Search")
                            }
                            IconButton(onClick = { screenMode = ScreenMode.Graph }) {
                                Icon(
                                    imageVector = Icons.Filled.AccountTree,
                                    contentDescription = "Knowledge Graph"
                                )
                            }
                            IconButton(onClick = { screenMode = ScreenMode.Settings }) {
                                Icon(
                                    imageVector = Icons.Filled.Settings,
                                    contentDescription = "Settings"
                                )
                            }
                        }
                    }
                )
            },
            floatingActionButton = {
                if (currentNote == null) {
                    var isFabMenuOpen by remember { mutableStateOf(false) }
                    Box {
                        FloatingActionButton(onClick = {
                            isFabMenuOpen = !isFabMenuOpen
                        }) {
                            Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Note")
                        }
                        DropdownMenu(
                            expanded = isFabMenuOpen,
                            onDismissRequest = { isFabMenuOpen = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Folder") },
                                onClick = {
                                    isFabMenuOpen = false
                                    viewModel.createNote(
                                        title = "New Folder",
                                        type = NoteType.FOLDER,
                                        parentNoteId = selectedFolderId
                                    )
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Handwritten note") },
                                onClick = {
                                    isFabMenuOpen = false
                                    viewModel.createNote(
                                        title = "New Handwritten Note",
                                        type = NoteType.CANVAS,
                                        parentNoteId = selectedFolderId
                                    )
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Typed note") },
                                onClick = {
                                    isFabMenuOpen = false
                                    viewModel.createNote(
                                        title = "New Text Note",
                                        type = NoteType.TEXT,
                                        parentNoteId = selectedFolderId
                                    )
                                }
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            if (screenMode == ScreenMode.Graph) {
                KnowledgeGraphScreen(
                    viewModel = viewModel,
                    onBack = { screenMode = ScreenMode.Home },
                    onOpenNote = { id ->
                        viewModel.selectNoteById(id)
                        screenMode = ScreenMode.Home
                    }
                )
            } else if (currentNote != null) {
                if (currentNote!!.type == NoteType.CANVAS) {
                    CanvasDetail(note = currentNote!!, viewModel = viewModel)
                } else {
                    NoteDetail(note = currentNote!!, viewModel = viewModel)
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.3f)
                            .fillMaxHeight()
                            .padding(8.dp)
                    ) {
                        FolderTree(
                            viewModel = viewModel,
                            onFolderSelected = { folderId -> selectedFolderId = folderId },
                            selectedNoteId = selectedFolderId
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant)
                    )

                    Column(
                        modifier = Modifier
                            .weight(0.7f)
                            .fillMaxHeight()
                            .padding(8.dp)
                    ) {
                        when (screenMode) {
                            ScreenMode.Search -> AdvancedSearchAndOCR(viewModel = viewModel)
                            ScreenMode.Settings -> {
                                val toolbarPos by viewModel.toolbarPosition.collectAsState()
                                val grid by viewModel.canvasGridEnabled.collectAsState()
                                val dots by viewModel.canvasDotsEnabled.collectAsState()
                                val stylusOnly by viewModel.stylusOnly.collectAsState()
                                SettingsPage(
                                    toolbarPosition = toolbarPos,
                                    onToolbarPositionChange = { viewModel.setToolbarPosition(it) },
                                    gridEnabled = grid,
                                    onGridToggle = { viewModel.setCanvasGridEnabled(it) },
                                    dotsEnabled = dots,
                                    onDotsToggle = { viewModel.setCanvasDotsEnabled(it) },
                                    stylusOnly = stylusOnly,
                                    onStylusOnlyToggle = { viewModel.setStylusOnly(it) }
                                )
                            }
                            else -> FolderViewer(
                                viewModel = viewModel,
                                selectedFolderId = selectedFolderId
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CanvasDetail(note: Note, viewModel: NoteViewModel) {
    val toolbarPos by viewModel.toolbarPosition.collectAsState()
    val showGrid by viewModel.canvasGridEnabled.collectAsState()
    val showDots by viewModel.canvasDotsEnabled.collectAsState()
    val stylusOnly by viewModel.stylusOnly.collectAsState()
    val strokes by viewModel.strokes.collectAsState()
    var currentStroke by remember { mutableStateOf<Stroke?>(null) }
    var currentTool by remember { mutableStateOf(ToolType.PEN) }
    var strokeColor by remember { mutableStateOf(Color.Black) }
    var strokeWidth by remember { mutableFloatStateOf(6f) } // Changed to mutableFloatStateOf
    val undoStack = remember { mutableStateListOf<Stroke>() }
    val redoStack = remember { mutableStateListOf<Stroke>() }

    Box(modifier = Modifier.fillMaxSize()) {
        DrawingCanvas(
            strokes = strokes,
            currentStroke = currentStroke,
            onStrokeStart = { s -> currentStroke = s.copy(noteId = note.id) },
            onStrokeUpdate = { s -> currentStroke = s.copy(noteId = note.id) },
            onStrokeEnd = { s ->
                val finalStroke = s.copy(noteId = note.id)
                viewModel.addStroke(finalStroke)
                undoStack.add(finalStroke)
                redoStack.clear()
                currentStroke = null
            },
            toolType = currentTool,
            strokeColor = strokeColor,
            strokeWidth = strokeWidth,
            showGrid = showGrid,
            showDots = showDots,
            stylusOnly = stylusOnly,
            onEraseStrokes = { toDelete ->
                toDelete.forEach { viewModel.deleteStroke(it) }
            }
        )

        CanvasToolbar(
            currentTool = currentTool,
            color = strokeColor,
            width = strokeWidth,
            opacity = strokeColor.alpha,
            grid = showGrid,
            dots = showDots,
            stylusOnly = stylusOnly,
            canUndo = strokes.isNotEmpty(),
            canRedo = redoStack.isNotEmpty(),
            onToolChange = { currentTool = it },
            onColorChange = { strokeColor = it },
            onWidthChange = { strokeWidth = it },
            onOpacityChange = { alpha -> strokeColor = strokeColor.copy(alpha = alpha) },
            onGridToggle = { viewModel.setCanvasGridEnabled(it) },
            onDotsToggle = { viewModel.setCanvasDotsEnabled(it) },
            onStylusOnlyToggle = { viewModel.setStylusOnly(it) },
            onUndo = {
                if (strokes.isNotEmpty()) {
                    val last = strokes.last()
                    redoStack.add(last)
                    viewModel.deleteStroke(last)
                }
            },
            onRedo = {
                if (redoStack.isNotEmpty()) {
                    val stroke = redoStack.removeAt(redoStack.lastIndex)
                    viewModel.addStroke(stroke)
                }
            },
            onClear = { viewModel.clearStrokes(); redoStack.clear() },
            onExport = { /* TODO: implement export */ },
            modifier = Modifier
                .align(if (toolbarPos == ToolbarPosition.TOP) androidx.compose.ui.Alignment.TopCenter else androidx.compose.ui.Alignment.BottomCenter)
                .padding(12.dp)
        )
    }
}

@Composable
fun SettingsPage(
    toolbarPosition: ToolbarPosition,
    onToolbarPositionChange: (ToolbarPosition) -> Unit,
    gridEnabled: Boolean,
    onGridToggle: (Boolean) -> Unit,
    dotsEnabled: Boolean,
    onDotsToggle: (Boolean) -> Unit,
    stylusOnly: Boolean,
    onStylusOnlyToggle: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)

        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Canvas toolbar on top")
            Switch(
                checked = toolbarPosition == ToolbarPosition.TOP,
                onCheckedChange = { isTop ->
                    onToolbarPositionChange(if (isTop) ToolbarPosition.TOP else ToolbarPosition.BOTTOM)
                }
            )
        }

        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Show grid")
            Switch(checked = gridEnabled, onCheckedChange = onGridToggle)
        }

        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Show dots")
            Switch(checked = dotsEnabled, onCheckedChange = onDotsToggle)
        }

        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Stylus only drawing")
            Switch(checked = stylusOnly, onCheckedChange = onStylusOnlyToggle)
        }
    }
}

@Composable
fun AdvancedSearchAndOCR(viewModel: NoteViewModel) {
    var searchQuery by remember { mutableStateOf(TextFieldValue("")) }
    val results by viewModel.searchResults.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Search", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = searchQuery,
            onValueChange = {
                searchQuery = it
                viewModel.searchNotes(it.text)
            },
            label = { Text("Search Notes") },
            modifier = Modifier.fillMaxWidth()
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            items(results) { note: Note -> // Corrected items usage and added type for note
                Text(
                    text = note.title, // Ensure note has a title property
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectNote(note) } // Corrected clickable usage
                        .padding(vertical = 8.dp)
                )
            }
        }
    }
}

private enum class ScreenMode { Home, Search, Settings, Graph }
