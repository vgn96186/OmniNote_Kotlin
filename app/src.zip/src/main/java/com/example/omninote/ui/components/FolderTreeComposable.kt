package com.example.omninote.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.omninote.data.Note
import com.example.omninote.data.NoteType
import com.example.omninote.viewmodel.NoteViewModel

@Composable
fun FolderTree(
    viewModel: NoteViewModel,
    onFolderSelected: (Long?) -> Unit,
    selectedNoteId: Long?
) {
    val topLevelNotes by viewModel.topLevelNotes.collectAsState(initial = emptyList())
    val expandedState = remember { mutableStateOf(setOf<Long>()) }

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Folders",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            if (selectedNoteId != null) {
                IconButton(
                    onClick = { onFolderSelected(null) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Go to root",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
        
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(topLevelNotes, key = { it.id }) { note ->
                FolderTreeItem(
                    note = note,
                    viewModel = viewModel,
                    onFolderSelected = onFolderSelected,
                    selectedNoteId = selectedNoteId,
                    expandedState = expandedState.value,
                    onToggleExpand = { id ->
                        expandedState.value = if (expandedState.value.contains(id)) {
                            expandedState.value - id
                        } else {
                            expandedState.value + id
                        }
                    },
                    depth = 0
                )
            }
        }
    }
}

@Composable
private fun FolderTreeItem(
    note: Note,
    viewModel: NoteViewModel,
    onFolderSelected: (Long?) -> Unit,
    selectedNoteId: Long?,
    expandedState: Set<Long>,
    onToggleExpand: (Long) -> Unit,
    depth: Int
) {
    val childNotes by viewModel.getChildNotes(note.id).collectAsState(initial = emptyList())
    val isFolder = note.type == NoteType.FOLDER

    val isSelected = note.id == selectedNoteId
    val isExpanded = expandedState.contains(note.id)

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (isFolder) {
                        onToggleExpand(note.id)
                        onFolderSelected(note.id)
                    } else {
                        onFolderSelected(note.parentNoteId)
                    }
                }
                .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                .padding(vertical = 8.dp, horizontal = 4.dp)
        ) {
            if (isFolder) {
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandMore else Icons.Default.ChevronRight,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    modifier = Modifier.padding(end = 4.dp)
                )
                Icon(
                    Icons.Default.Folder,
                    contentDescription = "Folder",
                    modifier = Modifier.padding(end = 4.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    modifier = Modifier.padding(end = 4.dp),
                    tint = Color.Transparent
                )
                val noteIcon = when (note.type) {
                    NoteType.CANVAS -> Icons.Default.Draw
                    NoteType.TEXT -> Icons.Default.Description
                    NoteType.KNOWLEDGE_GRAPH -> Icons.Default.AccountTree
                    else -> Icons.Default.Note // fallback for any other type
                }
                Icon(noteIcon, contentDescription = "Note", modifier = Modifier.padding(end = 4.dp))
            }
            Text(note.title, style = MaterialTheme.typography.bodyMedium)
        }

        if (isFolder && isExpanded && childNotes.isNotEmpty()) {
            Column(modifier = Modifier.padding(start = 16.dp)) {
                childNotes.forEach { childNote ->
                    FolderTreeItem(
                        note = childNote,
                        viewModel = viewModel,
                        onFolderSelected = onFolderSelected,
                        selectedNoteId = selectedNoteId,
                        expandedState = expandedState,
                        onToggleExpand = onToggleExpand,
                        depth = depth + 1
                    )
                }
            }
        }
    }
}