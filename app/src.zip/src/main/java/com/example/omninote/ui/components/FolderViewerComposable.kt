package com.example.omninote.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.omninote.data.Note
import com.example.omninote.data.NoteType
import com.example.omninote.data.Stroke as NoteStroke
import com.example.omninote.viewmodel.NoteViewModel

@Composable
fun FolderViewer(
    viewModel: NoteViewModel,
    selectedFolderId: Long?
) {
    val notesInFolder by if (selectedFolderId == null) {
        viewModel.topLevelNotes.collectAsState(initial = emptyList())
    } else {
        viewModel.getChildNotes(selectedFolderId).collectAsState(initial = emptyList())
    }

    val allNotes by viewModel.notes.collectAsState()
    val currentNote by viewModel.currentNote.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Breadcrumbs
        Breadcrumbs(
            path = buildBreadcrumbs(allNotes, selectedFolderId),
            onCrumbClick = { }
        )

        if (notesInFolder.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                    Text(
                        "Empty folder",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 180.dp),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(notesInFolder, key = { it.id }) { note ->
                    NoteThumbnail(
                        note = note,
                        isSelected = note.id == currentNote?.id,
                        onClick = { viewModel.selectNote(note) },
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

private fun buildBreadcrumbs(allNotes: List<Note>, selectedFolderId: Long?): List<Note> {
    if (selectedFolderId == null) return emptyList()
    val idToNote = allNotes.associateBy { it.id }
    val path = mutableListOf<Note>()
    var current = idToNote[selectedFolderId]
    while (current != null) {
        path.add(current)
        current = current.parentNoteId?.let { idToNote[it] }
    }
    return path.reversed()
}

@Composable
private fun Breadcrumbs(path: List<Note>, onCrumbClick: (Long?) -> Unit) {
    if (path.isEmpty()) return
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Home,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            path.forEach { note ->
                Icon(
                    Icons.Default.ChevronRight,
                    contentDescription = null,
                    modifier = Modifier
                        .size(16.dp)
                        .padding(horizontal = 4.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    note.title,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun NoteThumbnail(
    note: Note,
    isSelected: Boolean,
    onClick: () -> Unit,
    viewModel: NoteViewModel
) {
    Card(
        modifier = Modifier
            .aspectRatio(0.8f)
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) 8.dp else 2.dp
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) 
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
            else 
                MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Icon and type indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val (icon, color) = when (note.type) {
                    NoteType.CANVAS -> Icons.Default.Draw to Color(0xFF6366F1)
                    NoteType.TEXT -> Icons.Default.Description to Color(0xFF059669)
                    NoteType.KNOWLEDGE_GRAPH -> Icons.Default.AccountTree to Color(0xFFDC2626)
                    NoteType.FOLDER -> Icons.Default.Folder to Color(0xFFD97706)
                }
                
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(color.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        icon,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = color
                    )
                }
                
                if (isSelected) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
            
            Spacer(Modifier.height(12.dp))
            
            // Preview content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                when (note.type) {
                    NoteType.CANVAS -> CanvasThumbnail(noteId = note.id, viewModel = viewModel)
                    NoteType.TEXT -> TextPreview(content = note.content)
                    NoteType.KNOWLEDGE_GRAPH -> GraphPreview()
                    NoteType.FOLDER -> FolderPreview()
                }
            }
            
            Spacer(Modifier.height(12.dp))
            
            // Title
            Text(
                note.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CanvasThumbnail(noteId: Long, viewModel: NoteViewModel) {
    val strokes by viewModel.strokesForNote(noteId).collectAsState(initial = emptyList())
    
    if (strokes.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Empty Canvas",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }
    
    Canvas(modifier = Modifier.fillMaxSize()) {
        val allPoints = strokes.flatMap { it.points }
        if (allPoints.isEmpty()) return@Canvas
        
        val minX = allPoints.minOf { it.x }
        val minY = allPoints.minOf { it.y }
        val maxX = allPoints.maxOf { it.x }
        val maxY = allPoints.maxOf { it.y }
        
        val scaleX = if (maxX > minX) size.width / (maxX - minX) else 1f
        val scaleY = if (maxY > minY) size.height / (maxY - minY) else 1f
        val scale = minOf(scaleX, scaleY) * 0.8f
        
        val offsetX = (size.width - (maxX - minX) * scale) / 2
        val offsetY = (size.height - (maxY - minY) * scale) / 2
        
        strokes.take(50).forEach { stroke ->
            if (stroke.points.size >= 2) {
                for (i in 0 until stroke.points.size - 1) {
                    val p1 = stroke.points[i]
                    val p2 = stroke.points[i + 1]
                    drawLine(
                        color = Color(stroke.color).copy(alpha = 0.8f),
                        start = androidx.compose.ui.geometry.Offset(
                            (p1.x - minX) * scale + offsetX,
                            (p1.y - minY) * scale + offsetY
                        ),
                        end = androidx.compose.ui.geometry.Offset(
                            (p2.x - minX) * scale + offsetX,
                            (p2.y - minY) * scale + offsetY
                        ),
                        strokeWidth = (stroke.strokeWidth * scale * 0.5f).coerceAtLeast(1f),
                        cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

@Composable
private fun TextPreview(content: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        Text(
            content.take(100),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun GraphPreview() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(60.dp)) {
            val center = androidx.compose.ui.geometry.Offset(size.width / 2, size.height / 2)
            val radius = size.minDimension / 6
            
            // Draw simple graph nodes
            val positions = listOf(
                center + androidx.compose.ui.geometry.Offset(-radius, -radius),
                center + androidx.compose.ui.geometry.Offset(radius, -radius),
                center + androidx.compose.ui.geometry.Offset(0f, radius)
            )
            
            // Draw connections
            positions.forEach { pos1 ->
                positions.forEach { pos2 ->
                    if (pos1 != pos2) {
                        drawLine(
                            color = Color(0xFF6366F1).copy(alpha = 0.3f),
                            start = pos1,
                            end = pos2,
                            strokeWidth = 1.5f
                        )
                    }
                }
            }
            
            // Draw nodes
            positions.forEach { pos ->
                drawCircle(
                    color = Color(0xFF6366F1),
                    radius = 4f,
                    center = pos
                )
            }
        }
    }
}

@Composable
private fun FolderPreview() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            repeat(3) { index ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.8f - index * 0.1f)
                        .height(8.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            MaterialTheme.colorScheme.onSurfaceVariant.copy(
                                alpha = 0.3f - index * 0.1f
                            )
                        )
                )
            }
        }
    }
}